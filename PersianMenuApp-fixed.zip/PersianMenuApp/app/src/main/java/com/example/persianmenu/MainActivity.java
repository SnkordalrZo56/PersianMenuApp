package com.example.persianmenu;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int PICK_BACKGROUND_IMAGE = 1001;
    private static final String PREFS_NAME = "app_prefs";
    private static final String KEY_BACKGROUND_URI = "background_uri";

    private ImageView backgroundImage;
    private LinearLayout menuPanel;
    private LinearLayout submenuPanel;
    private TextView pageTitle;
    private TextView contentText;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        backgroundImage = findViewById(R.id.backgroundImage);
        menuPanel = findViewById(R.id.menuPanel);
        submenuPanel = findViewById(R.id.submenuPanel);
        pageTitle = findViewById(R.id.pageTitle);
        contentText = findViewById(R.id.contentText);

        Button menuButton = findViewById(R.id.menuButton);
        Button sectionsButton = findViewById(R.id.sectionsButton);
        Button homeButton = findViewById(R.id.homeButton);
        Button aboutButton = findViewById(R.id.aboutButton);
        Button changeBackgroundButton = findViewById(R.id.changeBackgroundButton);
        Button resetBackgroundButton = findViewById(R.id.resetBackgroundButton);

        preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        loadSavedBackground();

        menuButton.setOnClickListener(v -> toggleView(menuPanel));
        sectionsButton.setOnClickListener(v -> toggleView(submenuPanel));

        homeButton.setOnClickListener(v -> {
            pageTitle.setText("صفحه اصلی");
            contentText.setText(getString(R.string.home_text));
            closeMenu();
        });

        aboutButton.setOnClickListener(v -> {
            pageTitle.setText("درباره برنامه");
            contentText.setText(getString(R.string.about_text));
            closeMenu();
        });

        changeBackgroundButton.setOnClickListener(v -> openImagePicker());

        resetBackgroundButton.setOnClickListener(v -> {
            preferences.edit().remove(KEY_BACKGROUND_URI).apply();
            backgroundImage.setImageResource(R.drawable.default_background);
            Toast.makeText(this, "پس‌زمینه به حالت پیش‌فرض برگشت.", Toast.LENGTH_SHORT).show();
            closeMenu();
        });
    }

    private void toggleView(View view) {
        view.setVisibility(view.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    private void closeMenu() {
        submenuPanel.setVisibility(View.GONE);
        menuPanel.setVisibility(View.GONE);
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_BACKGROUND_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_BACKGROUND_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            if (imageUri == null) {
                return;
            }

            try {
                int takeFlags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                getContentResolver().takePersistableUriPermission(imageUri, takeFlags);
            } catch (SecurityException ignored) {
                // بعضی فایل‌پیکرها مجوز دائمی نمی‌دهند؛ برنامه همچنان تلاش می‌کند URI را ذخیره کند.
            }

            preferences.edit().putString(KEY_BACKGROUND_URI, imageUri.toString()).apply();
            backgroundImage.setImageURI(imageUri);
            Toast.makeText(this, "تصویر پس‌زمینه تغییر کرد.", Toast.LENGTH_SHORT).show();
            closeMenu();
        }
    }

    private void loadSavedBackground() {
        String savedUri = preferences.getString(KEY_BACKGROUND_URI, null);
        if (savedUri == null) {
            backgroundImage.setImageResource(R.drawable.default_background);
            return;
        }

        try {
            backgroundImage.setImageURI(Uri.parse(savedUri));
        } catch (Exception e) {
            preferences.edit().remove(KEY_BACKGROUND_URI).apply();
            backgroundImage.setImageResource(R.drawable.default_background);
        }
    }
}
